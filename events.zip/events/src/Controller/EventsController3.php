<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use  Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use App\Entity\Events;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;

class EventsController extends AbstractController
{
    /**
     * @Route("/", name="home_page")
     */
    public function index()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findAll();
     
        return $this->render('events/index.html.twig', array('events'=>$events));
    }

       /**
    * @Route("/create", name="create_page")
    */
    public function createAction(Request $request)
   {
       $events = new Events;

       $form = $this->createFormBuilder($events)
       ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
       ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:20px')))
       ->add('capacity', ChoiceType::class, array('choices'=>array('100'=>'100', '500'=>'500', '1K'=>'1K'),'attr' => array('style'=>'margin-botton:15px')))
       ->add('email', EmailType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('phone', NumberType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('address', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('web', UrlType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('type', ChoiceType::class, array('choices'=>array('music'=>'music', 'sport'=>'sport', 'art'=>'art', 'theatre'=>'theatre'),'attr' => array('style'=>'margin-botton:15px')))
       ->add('image', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
       ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-botton:15px')))
       ->getForm();
   
       $form->handleRequest($request);

       if($form->isSubmitted() && $form->isValid()){
        //fetching data
            $name = $form['name']->getData();
            $date = $form['date']->getData();
            $description = $form['description']->getData();
            $capacity = $form['capacity']->getData();
            $email = $form['email']->getData();
            $phone = $form['phone']->getData();
            $address = $form['address']->getData();
            $web = $form['web']->getData();
            $type = $form['type']->getData();  
            $image = $form['image']->getData();

            $events->setName($name);
            $events->setDate($date);
            $events->setDescription($description);
            $events->setCapacity($capacity);
            $events->setEmail($email);
            $events->setPhone($phone);
            $events->setAddress($address);
            $events->setWeb($web);
            $events->setType($type);
            $events->setImage($image);

            $em = $this->getDoctrine()->getManager();
            $em->persist($events);
            $em->flush();
            $this->addFlash(
                    'notice',
                    'An Event has been Added Succesfully'
                    );
            return $this->redirectToRoute('home_page');
       }


       return $this->render('events/create.html.twig', array('form' => $form->createView()));
   }

   /**
    * @Route("/edit/{id}", name="edit_page")
    */
   public function editAction($id, Request $request)
   {

    $events = $this->getDoctrine()->getRepository('App:Events')->find($id);

    $events->setName($events->getName());
    $events->setDate($events->getDate());
    $events->setDescription($events->getDescription());
    $events->setCapacity($events->getCapacity());
    $events->setEmail($events->getEmail());
    $events->setPhone($events->getPhone());
    $events->setAddress($events->getAddress());
    $events->setWeb($events->getWeb());
    $events->setType($events->getType());

    $form = $this->createFormBuilder($events)
    ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
    ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
    ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:20px')))
    ->add('capacity', ChoiceType::class, array('choices'=>array('100'=>'100', '500'=>'500', '1K'=>'1K'),'attr' => array('style'=>'margin-botton:15px')))
    ->add('email', EmailType::class, array('attr' => array('style'=>'margin-bottom:15px')))
    ->add('phone', NumberType::class, array('attr' => array('style'=>'margin-bottom:15px')))
    ->add('address', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
    ->add('web', UrlType::class, array('attr' => array('style'=>'margin-bottom:15px')))
    ->add('type', ChoiceType::class, array('choices'=>array('music'=>'music', 'sport'=>'sport', 'art'=>'art', 'theatre'=>'theatre'),'attr' => array('style'=>'margin-botton:15px')))
    ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-botton:15px')))
    ->getForm();

    $form->handleRequest($request);

    if($form->isSubmitted() && $form->isValid()) {
               //fetching data
               $name = $form['name']->getData();
               $date = $form['date']->getData();
               $description = $form['description']->getData();
               $capacity = $form['capacity']->getData();
               $email = $form['email']->getData();
               $phone = $form['phone']->getData();
               $address = $form['address']->getData();
               $web = $form['web']->getData();
               $type = $form['type']->getData();

               $em = $this->getDoctrine()->getManager();
               $events = $em->getRepository('App:Events')->find($id);
               $events->setName($name);
               $events->setDate($date);
               $events->setDescription($description);
               $events->setCapacity($capacity);
               $events->setEmail($email);
               $events->setPhone($phone);
               $events->setAddress($address);
               $events->setWeb($web);
               $events->setType($type);

               $em->flush();
               $this->addFlash(
                'notice',
                'An Event has been Updated'
                );
                return $this->redirectToRoute('home_page');
    }
       
    return $this->render('events/edit.html.twig', array('events'=>$events, 'form'=>$form->createView()));
   }

   /**
    * @Route("/details/{id}", name="details_page")
    */
   public function detailsAction($id)
   {
    $events = $this->getDoctrine()->getRepository('App:Events')->find($id);
    return $this->render('events/details.html.twig', array('events'=> $events));
   }

   /**
    * @Route("/delete/{id}", name="delete_page")
    */
    public function deleteAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $events = $em->getRepository('App:Events')->find($id);

        $em->remove($events);
        $em->flush();
        $this->addFlash(
            'notice',
            'Event Removed'
        );
        return $this->redirectToRoute('home_page');
    }

    /**
    * @Route("/sort/", name="sort_page")
    */
    public function filterAction(Request $request){

            $events = $this->getDoctrine()->getRepository('App:Events')->findAll();
            return $this->render('events/sort.html.twig', array('events' => $events));
    }




}
